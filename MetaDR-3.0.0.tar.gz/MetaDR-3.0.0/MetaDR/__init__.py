

from MetaDR import EpCNN
from MetaDR import WeighRF


# from pip import main
# from sklearn.metrics import roc_auc_score
# import argparse as ap
# import os
# from sklearn import preprocessing
# import sys
# import tensorflow
# from tensorflow.keras.models import Sequential
# from tensorflow.keras.layers import Convolution2D, Dense, Flatten, MaxPooling2D
# from numpy import *
# from sklearn import *
# import pandas as pd
# import numpy as np
# from tensorflow.keras.utils import to_categorical
# from sklearn.model_selection import train_test_split
# from tensorflow.keras import backend as K
# from tensorflow.keras.callbacks import EarlyStopping
# from numpy.random import seed
# # from tensorflow import set_random_seed
# import time


# import argparse as ap
# import pandas as pd
# import numpy as np
# import sys
# from sklearn import preprocessing
# from ete3 import NCBITaxa


# import argparse as ap
# import pandas as pd
# import numpy as np
# import sys
# from sklearn import preprocessing


# import argparse as ap
# import pandas as pd
# import numpy as np
# import sys
# import os
# from sklearn import preprocessing
# from sklearn.model_selection import train_test_split
# from sklearn.metrics import roc_auc_score
# import time
# import os
# from scipy import stats
# from numpy.random import seed
# from sklearn.model_selection import RandomizedSearchCV
# from sklearn.ensemble import RandomForestClassifier
# from sklearn.feature_selection import SelectFromModel


# # from metaDR import 1234
# # model = EfficientNet.from_pretrained('efficientnet-b0')



# from EpCNN import EPCNN_EV_main
# from EPCNN_PS import EPCNN_PS_main
# from WeighRF import WRF_EV_main
# from WRF_FS import WRF_FS_main


# EPCNN_EV_main(file_name='Karlsson_T2D',et='t',ts=0.3,rs=2)  # --fn Karlsson_T2D --et t --ts 0.3 --rs 2
# EPCNN_PS_main(file_name='Karlsson_T2D')   # 'Karlsson_T2D'  
# WRF_EV_main(file_name='Karlsson_T2D',rs=2,ts=0.3)  # python3 WRF_EV.py --fn Karlsson_T2D --rs 2 --ts 0.3
# WRF_FS_main(file_name='Karlsson_T2D',rs=2,tp=0.3)  # python3 WRF_FS.py --fn Karlsson_T2D --rs 2 --tp 30






